package com.cg.service;

public class Validations {

	public boolean checkName(String name) {
		String pattern="[A-Z][a-z]*";
		if(name.matches(pattern))
		{
			return true;
		}
		else
	
		{
		return false;
		}
	}

	public boolean checkadharnum(String adharnum) {
		if(adharnum.length()==12)
		{
			return true;
		}
		else
		{
		return false;
	}
	}


	}
	

