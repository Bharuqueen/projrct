package com.cg.service;

import java.util.List;

import com.cg.bean.BankApplication;

public interface BankServiceI {
	 void createAccount();
	BankApplication ShowBalance();
	void Deposit();
	void Withdraw();
	void FundTransfer();
	 List<String> printTransactions();

}
