package com.cg.service;

import java.util.List;
import java.util.Scanner;

import com.cg.bean.BankApplication;
import com.cg.dao.BankDao;

public class BankService implements BankServiceI{
	 BankApplication  obj=new  BankApplication ();
Scanner sc1=new Scanner(System.in);

BankDao data=new BankDao();


	public void createAccount() {
		System.out.println("enter name");
		String name=sc1.next();
		obj.setName(name);
		System.out.println("enter adharnum");
		String adharnum=sc1.next();
		obj.setAdharnum(adharnum);
		System.out.println("enter phonenum");
		String phnnum=sc1.next();
	
		System.out.println("enter pin");
		int pin =sc1.nextInt();
		System.out.println("enter the amount to be deposited");
		obj.setBalance(sc1.nextInt());
		System.out.println("Account created successfully");
		data.storeCustDetails(obj);
		
		
		
		
	}

	public void FundTransfer() {
double i,accountno;
        
        do{
        System.out.println("enter the account number to which amount has to be credited:");
         accountno = sc1.nextDouble();
         i=BankDao.checkAccountNo(accountno);
        }
        while(i==1);
    do{
        System.out.println("enter the account number from where amount has to be debited:");
         accountno = sc1.nextDouble();
        i=BankDao.checkAccountNo(accountno);
    }
    while(i==1);
        System.out.println("enter the amount to be transferred");
        int amt = sc1.nextInt();
        double acctto = 0;
        BankDao.fundTransfer(accountno, acctto, amt);
    }

 

 


	public BankApplication ShowBalance() {
		double i,accountno;
        int k;
       int pin;
        do{
        System.out.println("enter account no");
         accountno = sc1.nextDouble();
        i=BankDao.checkAccountNo(accountno);
        }
        while(i==1);
        do{
        System.out.println("enter the pin");
         pin=sc1.nextInt();
        k=BankDao.checkPin(pin);
        }
        while(k==1);
        return BankDao.showAccountBalance(accountno, pin);
	}
	
		
	public void Deposit() {
		double i,accountno;
        do{
        System.out.println("enter the account no");
         accountno = sc1.nextDouble();
         i=BankDao.checkAccountNo(accountno);
        }
        while(i==1);
        System.out.println("enter the amount to be depoist:");
        int amt = sc1.nextInt();
        BankDao.deposit(accountno, amt);    
	
		
	}

	public void Withdraw() {
		double i,accountno;
        int pin;
        
        do{
        System.out.println("enter the account no");
         accountno = sc1.nextDouble();
         i=BankDao.checkAccountNo(accountno);
        }
        while(i==1);
        System.out.println("enter the amount to be withdrawn:");
        int amt = sc1.nextInt();
        BankDao.withDraw(accountno, amt);
	
		
	}

	public List<String> PrintTransactions() {
		 double i,accountno;
		 BankApplication b=new BankApplication();
	        do{
	        System.out.println("enter the account no");
	         accountno = sc1.nextDouble();
	         i= BankDao.checkAccountNo(accountno);
	        }
	        while(i==1);
	        
	        return  BankDao.printTransction(accountno);
	        }

	@Override
	public List<String> printTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	}



	

