package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.BankApplication;



public class BankDao {
static List < BankApplication> list = new ArrayList< BankApplication>();

    static{
    	 BankApplication b1 = new  BankApplication("Bharathi", "987654321234", "989796789", 6767, 5000, 1000);
    	 BankApplication b2 = new  BankApplication("Akhila", "987654321234", "6578987867", 6768, 1000, 1222);
    	 BankApplication b3 = new  BankApplication("Bharu", "987654321234", "8578987867", 6769, 1256, 1366);
    	 BankApplication b4 = new  BankApplication("siri", "987654321234", "7578676892", 6764, 5542, 1566);
        list.add(b1);
        list.add(b2);
        list.add(b3);
        list.add(b4);    
}
    private double accountNo;
public void storeCustDetails( BankApplication bdetails) {
        
        list.add(bdetails);
        System.out.println(list);
}
    public static BankApplication showAccountBalance(double accountno,String pin) {
    	 BankApplication bdetails=new BankApplication();
        for( BankApplication b1:list)
        {
        if(b1.getAccountno()==accountno)
        {
            bdetails=b1;
            break;
        }
        }
        
        return bdetails;        
    }
    public static void deposit(double accountno, int amt) {
        
    	 BankApplication b=new  BankApplication();
        for( BankApplication b1:list){
        if(b1.getAccountno()==accountno)
        {
            b=b1;
            break;
        }
        }
        b.setBalance(b.getBalance()+amt);
        System.out.println("amount successfully deposited");
        System.out.println("new balance:"+b.getBalance());
        b.setList(+amt+ " rupees successfully deposited");
        
    
    }
    public static void fundTransfer(double accountno, double acctto, int amt) {
    	 BankApplication b=new BankApplication();
        for( BankApplication b1:list){
        if(b1.getAccountno()==accountno)
        {
            b=b1;
            break;
        }
        }
        BankApplication b2=new  BankApplication();
        for( BankApplication bt:list){
            if(bt.getAccountno()==acctto)
            {
                b2=bt;
                break;
            }
                }
        if(b.getAccountno()!=b2.getAccountno())
        {    
        
        if(b.getBalance()>amt)
        {
                b.setBalance(b.getBalance()-amt);
            
                System.out.println("Amount successfull credited and deposited to required acccount no");
                System.out.println("new balance:"+b.getBalance());
                b2.setBalance(b.getBalance()+amt);
                b.setList(+amt+ "rupees Amount succcesfully transferred to required account:");
        }
            else
                System.out.println("Insufficient amount in your account");
        }
        else
        {
            System.out.println("acccounts are same and hence funds cannot be transferred");
        }
    }
    public static double checkAccountNo(double accountno) 
    {
        int b = 0;
        for(BankApplication b1 : list) { 
               if(b1.getAccountno()==accountno)
               {
                   b=1;
                  return accountno;
               }
            }
        if(b==0)
        {
            System.out.println("please enter a valid account number");
        }
    return 1;

 

        
    }
    
    


    public static  int checkPin(int pin) {
        int c = 0;
        for(BankApplication b1 : list) { 
               if(b1.getPin()==pin)
               {
                   c=1;
                  return 0;
               }
            }
        if(c==0)
        {
            System.out.println("please enter a valid pin");
        }
    return 1;
    }
    public static void withDraw(double accountno, int amt) {
    	BankApplication b=new BankApplication();
        for(BankApplication b1:list){
        if(b1.getAccountno()==accountno)
        {
            b=b1;
            break;
        }
        }
        if(b.getBalance()>amt){
            b.setBalance(b.getBalance()-amt);
            System.out.println("amount sucessfully withdrawn");
            System.out.println(b.getBalance());
            b.setList(+amt+ " rupees Amount withrawn");
        }
        
    }
    public static List<String> printTransction(double accountno) {
    	BankApplication b=new BankApplication();
        for(BankApplication b1:list)
        if(b1.getAccountno()== accountno)
        {
            b=b1;
            break;
        }
        return b.getList();
    }
	public static BankApplication showAccountBalance(double accountno2, int pin) {
		// TODO Auto-generated method stub
		return null;
	}
	
    
    
    
}

 
 

 


 