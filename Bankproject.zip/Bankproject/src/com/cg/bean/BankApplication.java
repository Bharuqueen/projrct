package com.cg.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.service.Validations;

public class BankApplication {
	private String name;
	private String adharnum;
	private String phnum;
	private int pin;
	private int balance;
	private double Accountno;
	private static double acctno=1000;
	private List<String> list = new ArrayList<String>();
	Validations valid=new Validations();
	Scanner sc=new Scanner(System.in);
	public String getName() {
		return name;
	}
	public void setName(String name) {
		  if(valid.checkName(name))
	        {
	        this.name = name;
	        }
	        else
	        {
	            System.out.println("Enter Valid Name:");
	            setName(sc.next());
	        }
		

	}
	public String getAdharnum() {
		return adharnum;
	}
	public void setAdharnum(String adharnum) {
		 if(valid.checkadharnum(adharnum))
	        {
				this.adharnum = adharnum;
	        }
	        else
	        {
	            System.out.println("Enter Valid adharnum:");
	            setName(sc.next());
	        }
	
	}
	public String getPhnum() {
		return phnum;
	}
	public void setPhnum(String phnum) {
		this.phnum = phnum;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
			this.pin = pin;      
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public double getAccountno() {
		return Accountno;
	}
	public void setAccountno(double accountno) {
		Accountno = accountno;
	}
	public static double getAcctno() {
		return acctno;
	}
	public static void setAcctno(double acctno) {
		 BankApplication.acctno = acctno;
	}
	public List<String> getList() {
		return list;
	}
	public void setList(String string) {
		list.add(string);
		this.list = list;
	}
	public BankApplication(String name, String adharnum, String phnum, int pin, int balance, double accountno) {
		super();
		this.name = name;
		this.adharnum = adharnum;
		this.phnum = phnum;
		this.pin = pin;
		this.balance = balance;
		Accountno = accountno;
		this.list = list;
	}
	public BankApplication() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BankDetails [name=" + name + ", adharnum=" + adharnum + ", phnum=" + phnum + ", pin=" + pin
				+ ", balance=" + balance + ", Accountno=" + Accountno + ", list=" + list + "]";
	}
	
	
	


}
