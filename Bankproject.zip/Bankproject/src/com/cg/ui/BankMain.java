package com.cg.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.service.BankService;

public class BankMain {
	public static void main(String[] args) 
	  {
		BankService service=new BankService();
		Scanner sc=new Scanner(System.in);
		for(;;)
		{
			

		int choice;
		System.out.println("Welcome to Yes Bank");
		System.out.println("Enter your choice");
		System.out.println("1.create Account\n2. Show Balance\n3. Deposit\n4. Withdraw\n5.Fund Transfer\n 6. Print Transactions");
		choice=sc.nextInt();
		switch(choice) {
		
		case 1:
		service.createAccount();
			break;
		case 2:
			service.ShowBalance();
			break;
		case 3:
			service.Deposit();
			break;
		case 4:
			service.Withdraw();
			break;
		case 5:
		service.FundTransfer();
			break;
		case 6:
			List<String> l1=new ArrayList<String>();
			l1=service.PrintTransactions();
			Iterator itr=(Iterator) l1.iterator();
			while(itr.hasNext()) {
				System.out.println(itr.next());
			}
		
			break;	
			default:
		}
				System.out.println("Do you want to 1.Continue or 2.End");
					 if(sc.nextInt()==1)
				        {
				            continue;
				        }
				        else
				        {
				            System.exit(0);
				        }
		
		}
	  }
}

